import{test,expect} from 'vitest'

//Exercício 01 Explique o que é um componente em React e como criar um componente utilizando TypeScript. 
//R: É uma função do JavaScript/TypeScript que tem um retorno de JSX.

function Header(){
	return (<h1>Header<h1>)
}

//Exercício 02 Quais são as vantagens de utilizar TypeScript ao invés de JavaScript?
//R: A vantagem é que você transorma o JavaScript que é uma linguagem não tipada em uma linguagem tipada com o TypeScript.

/**
 * Exercício 03 - Contagem de consoantes
 * Nome da função - contaConsoantes
 * Crie uma função que receba uma string e retorne a quantidade de consoantes presentes na string.
 * @param {string} str A string que será analisada
 * @returns {number} Retorna a quantidade de consoantes na string
 * @example
 * contaConsoantes("hello") // 3
 * contaConsoantes("abcdef") // 4
 */

// Início do seu código
function contaConsoantes(str:string) {
    let contador = 0
    for(let i=0;i<str.length;i++){
        if(str[i]!="a" &&
           str[i]!="e" && 
           str[i]!="i"&&
           str[i]!="o"&&
           str[i]!="u"&&
           str[i]!="A"&&
           str[i]!="E"&&
           str[i]!="I"&&
           str[i]!="O"&&
           str[i]!="U"
        ){
            contador++
        }
    }
    return contador
}

// Fim do seu código

test('contaConsoantes', () => {
    expect(contaConsoantes("hello")).toBe(3);
    expect(contaConsoantes("abcdef")).toBe(4);
    expect(contaConsoantes("xyz")).toBe(3);
    expect(contaConsoantes("AEIOU")).toBe(0);
});


/**
 * Exercício 04 - naoDivisivelPor7Ou9
 * Nome da função - naoDivisivelPor7Ou9
 * Crie uma função que retorna um array com os números não divisíveis por 7 ou por 9 no intervalo
 * @param {number} min Número mínimo
 * @param {number} max Número máximo
 * @returns {number[]} Retorna um array com os números não divisíveis por 7 ou por 9 no intervalo
 * @example
 * naoDivisivelPor7Ou9(1, 50) // [1, 2, 3, 4, 5, 6, 8, 10, 11, 12, 13, 15, 16, 17, 19, 20, 22, 23, 24, 25, 26, 29, 30, 31, 32, 33, 34, 37, 38, 39, 40, 41, 43, 44, 46, 47, 48, 50]
 * naoDivisivelPor7Ou9(7, 70) // [8, 10, 11, 12, 13, 15, 16, 17, 19, 20, 22, 23, 24, 25, 26, 29, 30, 31, 32, 33, 34, 37, 38, 39, 40, 41, 43, 44, 46, 47, 48, 50, 51, 52, 53, 55, 57, 58, 59, 60, 61, 62, 64, 65, 66, 67, 68, 69]
 */

//Início do seu código
function naoDivisivelPor7Ou9(a:number,b:number):number[]{
    const naoDivisores:number[] = []
    for(let i=a;i<=b;i++){
        if(i%7!=0&&i%9!=0){
            naoDivisores.push(i)
        }
    }
    return naoDivisores
}
//Fim do seu código

test('naoDivisivelPor7Ou9', () => {
    expect(naoDivisivelPor7Ou9(1, 50)).toEqual([1, 2, 3, 4, 5, 6, 8, 10, 11, 12, 13, 15, 16, 17, 19, 20, 22, 23, 24, 25, 26, 29, 30, 31, 32, 33, 34, 37, 38, 39, 40, 41, 43, 44, 46, 47, 48, 50])
})
test("naoDivisivelPor7Ou9 quando min = 7 e max = 70", () => {
    expect(naoDivisivelPor7Ou9(7, 70)).toEqual([8, 10, 11, 12, 13, 15, 16, 17, 19, 20, 22, 23, 24, 25, 26, 29, 30, 31, 32, 33, 34, 37, 38, 39, 40, 41, 43, 44, 46, 47, 48, 50, 51, 52, 53, 55, 57, 58, 59, 60, 61, 62, 64, 65, 66, 67, 68, 69])
})
test('naoDivisivelPor7Ou9 quando valores trocados', () => {
    expect(naoDivisivelPor7Ou9(50, 1)).toEqual([])
})

/**
 * Exercício 05 - resolveEquacao2
 * Nome da função - resolveEquacao2
 * Crie uma função que retorne os pontos em Y a partir de um vetor dos pontos em X da equação y
 * @param {number[]} vetor Vetor de pontos em X
 * @returns {number[]} Retorna um array com os pontos em Y
 * @example
 * resolveEquacao2([1, 2, 3]) // [5, 14, 49]
 */

//Início do seu código
function resolveEquacao2(v:number[]){
    const retorno:number[] = []
    for(let i=0;i<v.length;i++){
        let x = v[i]
        retorno.push(2*x**3 + x**2 -8*x + 10)
    }
    return retorno
}
//Fim do seu código

test('resolveEquacao2', () => {
    expect(resolveEquacao2([1, 2, 3])).toEqual([5, 14, 49])
})
test('resolveEquacao2 quando números negativos', () => {
    expect(resolveEquacao2([-1, -2, -3, -4])).toEqual([17, 14, -11, -70])
})

/**
 * Exercício 06 - Crie testes para a função saudacao e explique o que é um teste.
 * Nome da função - saudacao
 * @returns {string} Retorna "Olá, Mundo!"
 * @example
 * saudacao() // "Olá, Mundo!"
 */
function saudacao(): string {
    return 'Olá, Mundo!'
}

//Início do seu código
test("Teste da função saudacao",()=>{
    expect(saudacao()).toBe('Olá, Mundo!')
})

// Teste é uma ferramenta automatizada para verificar a funcionalidade de códigos.
//Fim do seu código
